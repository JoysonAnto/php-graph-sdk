<?php 
session_start();
require 'php-graph-sdk-5.5/src/Facebook/autoload.php';
require 'php-graph-sdk-5.5/src/Facebook/Facebook.php';
//use Facebook as Fb;
$fb_access_token=$_SESSION['fb_access_token'];
$fb = new \Facebook\Facebook([
  'app_id' => '119938078605366',
  'app_secret' => '042c9dda74d5de9f14624545d680453d',
  'default_graph_version' => 'v2.9',
  'default_access_token' => $fb_access_token, // optional
]);

try {
  // Get the \Facebook\GraphNodes\GraphUser object for the current user.
  // If you provided a 'default_access_token', the '{access-token}' is optional.
   $param='fields=id,name,posts{actions,caption,comments{can_like,comment_count,can_remove},likes{pic},message,full_picture,icon,reactions}';
 $request = $fb->get('/1721301684840587', $fb_access_token,$param);

 //echo $fb->getEndpoint();
  //$request = $fb->request('GET','1721301684840587',$param, 'EAABtFUKSADYBAMlKL8OLQJwGp6ZBAe0aBPHVz25iVnY83fN5ZBvI9TAvsrDSWEysPloxcXw1sWveTEJ0uMKIcG4ahDsyjaZASRJVSUZApBFUtvNwmFUJsFhGCbyTDTi8mQ6jNkANaEHemaRrMMloldyDX663zAxAtzSGkfPnYLuIxUD6KNQi8UxhZA2H5pPeqpMjXyl6iqwZDZD');
} catch(\Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(\Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}
//echo "<pre>"; print_r($request); echo "</pre>";
//$response=$request->execute();
$me = $request->getGraphUser();
//$me = $request->getGraphObject();
//echo "<pre>"; print_r($me); echo "</pre>";
 $param=array('fields'=>'id,name,posts{actions,caption,comments{can_like,comment_count,can_remove},likes{pic},message,full_picture,icon,reactions}');
 $endpoint='1721301684840587';
 $eTag='';
$request=$fb->sendRequest('GET',$endpoint,$param,$fb_access_token,$eTag);
echo "<pre>"; print_r($request); echo "</pre>";

$posts_obj=json_decode($request->getBody());
echo "<pre>"; print_r(json_encode($posts_obj->posts->data)); echo "</pre>"; # for object format data
//echo "<pre>"; print_r($request->getDecodedBody()); echo "</pre>"; # for array format data

/* PHP SDK v5.0.0 */
/* make the API call */
/*
$request = new FacebookRequest(
  $session,
  'GET',
  '/{page-id}'
);
$response = $request->execute();
$graphObject = $response->getGraphObject();
*/
/* handle the result */

//echo 'Logged in as ' . $me->getName();
/* handle the result */


?>
