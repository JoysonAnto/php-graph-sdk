<?php
defined('BASEPATH') OR exit('No direct script access allowed');
session_start();
require 'php-graph-sdk-5.5/src/Facebook/autoload.php';
require 'php-graph-sdk-5.5/src/Facebook/Facebook.php';

class Fbpage {
		public function __construct($param) {
			extract($param);
			$this->fb = new \Facebook\Facebook([
						'app_id' => $appid,
						'app_secret' => $app_secret,
						'default_graph_version' => 'v2.2',
					]);
			//$accessToken=$this->accessToken();
			//$this->pagedata=$this->getfbpage($accessToken);
			//echo "<pre>"; print_r($this->pagedata); echo "</pre>";
			
		}
		
		public function accessToken() {
			$fbApp = $this->fb->getApp();
			if(!isset($_SESSION['fb_access_token'])) {
				try {
					  $accessToken = $fbApp->getAccessToken();
					  //echo "<pre>"; print_r($accessToken); echo "</pre>";
					  return $accessToken;
					} catch(Facebook\Exceptions\FacebookResponseException $e) {
					  // When Graph returns an error
					  echo 'Graph returned an error: ' . $e->getMessage();
					  exit;
					} catch(Facebook\Exceptions\FacebookSDKException $e) {
					  // When validation fails or other local issues
					  echo 'Facebook SDK returned an error: ' . $e->getMessage();
					  exit;
					}
				if (! isset($accessToken)) {
				  echo 'No cookie set or no OAuth data could be obtained from cookie.';
				  exit;
				}
				$_SESSION['fb_access_token'] = (string) $accessToken;

			} else{
				$accessToken=$_SESSION['fb_access_token'];
				return $accessToken;
			}
		
				
		}

		public function getfbpage($fb_access_token) {
			$param=array('fields'=>'id,name,posts{caption,message,full_picture,comments{attachment,message,created_time,from,application},picture,updated_time,from},picture');
			 $endpoint='1721301684840587'; //page id
			 $eTag='';
			$request=$this->fb->sendRequest('GET',$endpoint,$param,$fb_access_token,$eTag);
			//echo "<pre>"; print_r($request); echo "</pre>";

			//$posts_obj=$request->getBody();# for object format data
			return $posts_objary=$request->getDecodedBody();# for array format data
			
			//echo "<pre>"; print_r($request->getDecodedBody()); echo "</pre>"; # for array format data

		}
}
?>